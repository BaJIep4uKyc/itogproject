import pygame as pg
import pygame

pg.init()

screen = pg.display.set_mode((600,700))

FPS = 60
clock = pg.time.Clock()

by = 550
px = 250
bulletimage = pg.image.load('bullet.png')
shipimage = pg.image.load('angryship.png')
friendlyshipimg = pg.image.load('friendlyship.png')

while True:
    for event in pg.event.get():
        if event.type == pg.QUIT:
            pg.quit()
            quit

    screen.fill((225,225,225))
    #screen.blit(bulletimage, (,py))
    screen.blit(shipimage, (250,250))
    screen.blit(friendlyshipimg, (px,550))

    #movement
    key = pg.key.get_pressed()
    if key[pg.K_a]:
        px -= 5
    if key[pg.K_d]:
        px += 5

    #barriers
    if px < 0:
        px = 0
    if px > 500:
        px = 500

    clock.tick(FPS)
    pg.display.update()